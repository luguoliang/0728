//
//  CustomLoginTextField.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/6/23.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "CustomLoginTextField.h"

@implementation CustomLoginTextField

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [UIColor colorWithRed:225.0f/255.0f green:225.0f/255.0f blue:225.0f/255.0f alpha:1.0f].CGColor);
    CGContextFillRect(context, CGRectMake(0, CGRectGetHeight(self.frame) - 0.5, CGRectGetWidth(self.frame), 0.5));
}

@end
