//
//  ViewController.m
//  fang
//
//  Created by 路国良 on 16/9/20.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "ViewController.h"
#import "ShareView.h"
//#import "UIView+TYAlertView.h"
#import "BaofooOperation.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)button:(id)sender {
//    ShareView *shareView = [ShareView createViewFromNib];
//    
//    // use UIView Category
//    [shareView showInWindow];
    

    BaofooOperation*oper = [[BaofooOperation alloc] init];
    [oper showPayView];
}
@end
