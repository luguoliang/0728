//
//  CustomLoginTextField.h
//  BaofooWallet
//
//  Created by 吴斌 on 16/6/23.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomLoginTextField : UITextField

@end
