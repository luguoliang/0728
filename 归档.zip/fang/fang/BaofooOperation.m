//
//  BaofooOperation.m
//  fang
//
//  Created by 路国良 on 16/9/20.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "BaofooOperation.h"
#import "UIView+TYAlertView.h"
#import "BaofooCertifePay.h"
@implementation BaofooOperation
-(void)showPayView{
    BaofooCertifePay*pay = [[BaofooCertifePay alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width*0.85, [UIScreen mainScreen].bounds.size.height*0.5)];
    [pay showInWindow];
}
@end

