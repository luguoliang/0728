//
//  BaofooCertifePay.m
//  fang
//
//  Created by 路国良 on 16/9/20.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "BaofooCertifePay.h"
#import "UIView+TYAlertView.h"
#import "CustomLoginTextField.h"
#import "CountdownButton.h"
#import "TYShowAlertView.h"
@interface BaofooCertifePay()
{
    
}
@property (nonatomic, strong) NSLayoutConstraint *alertViewCenterYConstraint;

@property (nonatomic, assign) CGFloat alertViewCenterYOffset;

@end

@implementation BaofooCertifePay

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor  = [UIColor whiteColor];
        [self loadView];
        
    }
    return self;
}

-(void)loadView{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    UILabel*titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 50)];
    [self addSubview:titleLabel];
    titleLabel.text = @"付款确认";
    titleLabel.font = [UIFont systemFontOfSize:20];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    UIView*lineView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(titleLabel.frame), self.frame.size.width, 0.5)];
    lineView.backgroundColor = [UIColor grayColor];
    [self addSubview:lineView];
    lineView.alpha = 0.5;
    
    UILabel*pnumberLabel = [[UILabel alloc] initWithFrame:CGRectMake(5,  CGRectGetMaxY(lineView.frame), self.frame.size.width - 10, 80)];
    pnumberLabel.numberOfLines = 0;
    pnumberLabel.text = @"本次交易需要短信确认，校验码已经发送至您的手机18217599130";
    titleLabel.font = [UIFont systemFontOfSize:20];
    [self addSubview:pnumberLabel];
    
    UITextField*textField = [[UITextField alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(pnumberLabel.frame), self.frame.size.width - 10, 50)];
    textField.placeholder = @"请输入短信验证码";
    textField.layer.borderColor= [UIColor grayColor].CGColor;
    
    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){0.1,0,0,0.1});
    [textField.layer setBorderWidth:0.5];
    [textField.layer setBorderColor:color];
    textField.rightViewMode = UITextFieldViewModeAlways;
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    textField.clearButtonMode = UITextFieldViewModeNever;
    
    CountdownButton* _getmessageButton = [CountdownButton buttonWithType:UIButtonTypeCustom];
    [_getmessageButton setTintColor:[UIColor colorWithRed:0.0/255.0f green:151.0/255.0f blue:209.0/255.0f alpha:1.0f]];
    [_getmessageButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_getmessageButton addTarget:self action:@selector(getCode:)forControlEvents:UIControlEventTouchUpInside];
    
    [_getmessageButton setTitle:@"获取" forState:UIControlStateNormal];
    _getmessageButton.titleLabel.font =[UIFont systemFontOfSize:15.0f];
    
    _getmessageButton.frame = CGRectMake(0, 0, 60, 30);
    
    
    textField.rightView = _getmessageButton;
    
    [self addSubview:textField];
    
    
    UIButton*cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelButton.frame = CGRectMake(0, self.frame.size.height - 50, (self.frame.size.width*0.5)-0.5, 50);
    cancelButton.backgroundColor = [UIColor colorWithRed:239.0/255.0f green:241.0/255.0f blue:243.0/255.0f alpha:1.0];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    cancelButton.titleLabel.font = [UIFont systemFontOfSize: 20.0];
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    cancelButton.titleLabel.textColor = [UIColor blackColor];
    [cancelButton addTarget:self action:@selector(cancelButton:) forControlEvents:UIControlEventTouchUpInside];
    [cancelButton.layer setBorderWidth:0.5];
    [cancelButton.layer setBorderColor:color];
    [self addSubview:cancelButton];
    
    
    UIButton*okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(CGRectGetMaxX(cancelButton.frame), self.frame.size.height - 50, (self.frame.size.width*0.5)+0.5, 50);
    okButton.backgroundColor = [UIColor colorWithRed:239.0/255.0f green:241.0/255.0f blue:243.0/255.0f alpha:1.0];
    [okButton setTitleColor:[UIColor colorWithRed:239.0/255.0f green:98.0/255.0f blue:51.0/255.0f alpha:1.0] forState:UIControlStateNormal];
     okButton.titleLabel.font = [UIFont systemFontOfSize: 20.0];
    [okButton setTitle:@"确定" forState:UIControlStateNormal];
    [okButton addTarget:self action:@selector(okenButton:) forControlEvents:UIControlEventTouchUpInside];
    [okButton setTitleColor:[UIColor colorWithRed:239.0/255.0f green:98.0/255.0f blue:51.0/255.0f alpha:0.2] forState:UIControlStateHighlighted];
    [okButton.layer setBorderWidth:0.5];
    [okButton.layer setBorderColor:color];
    [self addSubview:okButton];
}

-(void)cancelButton:(UIButton*)button{
     [self hideView];
}
-(void)okenButton:(UIButton*)button{
    
}
-(void)getCode:(CountdownButton*)btn{
    [btn countDownBegins];
}


//- (void)layoutAlertStyleView
//{
//    // center X
//    [self.view addConstraintCenterXToView:_alertView CenterYToView:nil];
//    
//    [self configureAlertViewWidth];
//    
//    // top Y
//    _alertViewCenterYConstraint = [self.view addConstraintCenterYToView:_alertView constant:0];
//    
//    if (_alertViewOriginY > 0) {
//        [_alertView layoutIfNeeded];
//        _alertViewCenterYOffset = _alertViewOriginY - (CGRectGetHeight(self.view.frame) - CGRectGetHeight(_alertView.frame))/2;
//        _alertViewCenterYConstraint.constant = _alertViewCenterYOffset;
//    }else{
//        _alertViewCenterYOffset = 0;
//    }
//}

//- (void)layoutActionSheetStyleView
//{
//    // remove width constaint
//    for (NSLayoutConstraint *constraint in _alertView.constraints) {
//        if (constraint.firstAttribute == NSLayoutAttributeWidth) {
//            [_alertView removeConstraint: constraint];
//            break;
//        }
//    }
//    
//    // add edge constraint
//    [self addConstarintWithView:_alertView topView:nil leftView:self.view bottomView:self.view rightView:self.view edageInset:UIEdgeInsetsMake(0, _actionSheetStyleEdging, 0, -_actionSheetStyleEdging)];
//    
//    if (CGRectGetHeight(_alertView.frame) > 0) {
//        // height
//        [_alertView addConstarintWidth:0 height:CGRectGetHeight(_alertView.frame)];
//    }
//}
//- (void)configureAlertViewWidth
//{
//    // width, height
//    if (!CGSizeEqualToSize(_alertView.frame.size,CGSizeZero)) {
//        [_alertView addConstarintWidth:CGRectGetWidth(_alertView.frame) height:CGRectGetHeight(_alertView.frame)];
//        
//    }else {
//        BOOL findAlertViewWidthConstraint = NO;
//        for (NSLayoutConstraint *constraint in _alertView.constraints) {
//            if (constraint.firstAttribute == NSLayoutAttributeWidth) {
//                findAlertViewWidthConstraint = YES;
//                break;
//            }
//        }
//        
//        if (!findAlertViewWidthConstraint) {
//            [_alertView addConstarintWidth:CGRectGetWidth(self.view.frame)-2*_alertStyleEdging height:0];
//        }
//    }
//}



- (void)keyboardWillShow:(NSNotification*)notification{
    CGRect keyboardRect = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    CGFloat alertViewBottomEdge = (CGRectGetHeight(self.frame) -  CGRectGetHeight(self.frame))/2 - _alertViewCenterYOffset;
    CGFloat differ = CGRectGetHeight(keyboardRect) - alertViewBottomEdge;
    
    if (differ >= 0) {
        _alertViewCenterYConstraint.constant = _alertViewCenterYOffset - differ;
        [UIView animateWithDuration:0.25 animations:^{
            [self layoutIfNeeded];
        }];
    }
    
//    [TYShowAlertView showAlertViewWithView:self originY:10];
  
//    [self showAlertViewWithView:self originY:10];
    
    
    
}


- (void)keyboardWillHide:(NSNotification*)notification{
    
    _alertViewCenterYConstraint.constant = _alertViewCenterYOffset;
    [UIView animateWithDuration:0.25 animations:^{
        [self layoutIfNeeded];
    }];
}


@end
