//
//  TYAlertDefaultAnimation.h
//  TYAlertControllerDemo
//
//  Created by SunYong on 15/9/1.
//  Copyright (c) 2015年 tanyang. All rights reserved.
//

#import "TYBaseAnimation.h"

@interface TYAlertFadeAnimation : TYBaseAnimation

@end
