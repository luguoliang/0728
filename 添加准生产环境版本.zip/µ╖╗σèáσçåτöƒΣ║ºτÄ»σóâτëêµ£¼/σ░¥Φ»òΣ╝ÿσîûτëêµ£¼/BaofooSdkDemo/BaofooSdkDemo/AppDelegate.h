//
//  AppDelegate.h
//  BaofooSdkDemo
//
//  Created by mac on 15/6/4.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

