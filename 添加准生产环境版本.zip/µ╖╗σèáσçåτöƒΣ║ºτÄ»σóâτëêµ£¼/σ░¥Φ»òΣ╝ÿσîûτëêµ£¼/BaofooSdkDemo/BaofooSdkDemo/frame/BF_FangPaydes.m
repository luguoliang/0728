//
//  BF_FangPaydes.m
//  BaofooSdkDemo
//
//  Created by 路国良 on 16/8/5.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BF_FangPaydes.h"

@implementation BF_FangPaydes
/******************************************************************************
 函数名称 : + (NSData *)DESEncrypt:(NSData *)data WithKey:(NSString *)key
 函数描述 : 文本数据进行DES加密
 输入参数 : (NSData *)data
 (NSString *)key
 输出参数 : N/A
 返回参数 : (NSData *)
 备注信息 : 此函数不可用于过长文本
 ******************************************************************************/
+ (NSString *)DESEncrypt:(NSString *)string WithKey:(NSString *)key
{
    
    //    Byte iv[] = {1,3,7,3,3,8,2,7};
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSUInteger dataLength = [data length];
    
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding|kCCOptionECBMode ,
                                          keyPtr, kCCBlockSizeDES,
                                          nil,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *desData = [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
        NSString *desString = [NSString stringWithFormat:@"%@",desData];
        desString = [desString stringByReplacingOccurrencesOfString:@"<" withString:@""];
        desString = [desString stringByReplacingOccurrencesOfString:@">" withString:@""];
        desString = [desString stringByReplacingOccurrencesOfString:@" " withString:@""];
        return desString;
    }
    
    free(buffer);
    return nil;
}

/******************************************************************************
 函数名称 : + (NSData *)DESEncrypt:(NSData *)data WithKey:(NSString *)key
 函数描述 : 文本数据进行DES解密
 输入参数 : (NSData *)data
 (NSString *)key
 输出参数 : N/A
 返回参数 : (NSData *)
 备注信息 : 此函数不可用于过长文本
 ******************************************************************************/
+ (NSData *)DESDecrypt:(NSData *)data WithKey:(NSString *)key
{
    //    Byte iv[] = {1,3,7,3,3,8,2,7};
    
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSUInteger dataLength = [data length];
    
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding,
                                          keyPtr, kCCBlockSizeDES,
                                          nil,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesDecrypted);
    
    if (cryptStatus == kCCSuccess) {
        return [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
    }
    
    free(buffer);
    return nil;
}

+ (NSString *)generate:(NSDictionary *)parameters {
    NSArray *keysArray = [[parameters allKeys] sortedArrayUsingSelector:@selector(compare:)];
    NSString *parametersString = [NSString string];
    for (NSString *string in keysArray) {
        parametersString =[parametersString stringByAppendingString:[NSString stringWithFormat:@"%@=%@&",string,parameters[string]]];
    }
    return [parametersString substringToIndex:parametersString.length-1];;
}

@end
