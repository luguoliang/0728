//
//  BF_FangPaydes.h
//  BaofooSdkDemo
//
//  Created by 路国良 on 16/8/5.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>
@interface BF_FangPaydes : NSObject
/******************************************************************************
 函数名称 : + (NSData *)DESEncrypt:(NSData *)data WithKey:(NSString *)key
 函数描述 : 文本数据进行DES加密
 输入参数 : (NSData *)data
 (NSString *)key
 输出参数 : N/A
 返回参数 : (NSData *)
 备注信息 : 此函数不可用于过长文本
 ******************************************************************************/
+ (NSString *)DESEncrypt:(NSString *)data WithKey:(NSString *)key;
/******************************************************************************
 函数名称 : + (NSData *)DESEncrypt:(NSData *)data WithKey:(NSString *)key
 函数描述 : 文本数据进行DES解密
 输入参数 : (NSData *)data
 (NSString *)key
 输出参数 : N/A
 返回参数 : (NSData *)
 备注信息 : 此函数不可用于过长文本
 ******************************************************************************/
+ (NSData *)DESDecrypt:(NSData *)data WithKey:(NSString *)key;
/******************************************************************************
 函数名称 : + (NSString *)generate:(NSDictionary *)parameters
 函数描述 : 将字典拼接成一个字符串
 输入参数 : (NSDictionary *)parameters;
 输出参数 : N/A
 返回参数 : (NSString *)
 备注信息 : 此函数不可用于过长文本
 ******************************************************************************/
+ (NSString *)generate:(NSDictionary *)parameters;

@end
