//
//  TextView.m
//  fang
//
//  Created by 路国良 on 16/9/21.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "TextView.h"
#import "BaofooCertifePay.h"
#import "BF_FangProgressHUD.h"

@interface TextView()<BF_FangSdkDelegate>
{
    BaofooCertifePay*_sview;
    UIView*ba;
    NSDictionary*_sendDict;
}


@end
@implementation TextView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)showPayViewWithDict:(NSDictionary *)dict{
    _sendDict = [NSDictionary dictionaryWithDictionary:dict];
    ba = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    ba.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.5];
    _sview = [[BaofooCertifePay alloc] initWithFrame:CGRectMake(([UIScreen mainScreen].bounds.size.width - ([UIScreen mainScreen].bounds.size.width*0.85))/2, ([UIScreen mainScreen].bounds.size.height - ([UIScreen mainScreen].bounds.size.height*0.5))/2,[UIScreen mainScreen].bounds.size.width*0.85, [UIScreen mainScreen].bounds.size.height*0.5)];
    _sview.backgroundColor = [UIColor whiteColor];
    _sview.mobile = dict[@"mobile"];
    _sview.delegate = self;
    [_sview codeStart];
    [ba addSubview:_sview];
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    [window addSubview:ba];
    
    
    self.alpha = 0;
    _sview.transform = CGAffineTransformScale(_sview.transform,0.1,0.1);
    [UIView animateWithDuration:0.3 animations:^{
        _sview.transform = CGAffineTransformIdentity;
        self.alpha = 1;
    }];

}

#pragma mark  -delegate
-(void)hide{
    [UIView animateWithDuration:0.3 animations:^{
        _sview.transform = CGAffineTransformScale(_sview.transform,0.1,0.1);
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        [_sview removeFromSuperview];
        [ba removeFromSuperview];
    }];
}
-(void)okenButtonWithMessageCode:(NSString*)messageCode{
    [BF_FangProgressHUD showHUDAddedTo:self animated:YES];
    NSURL*url = [NSURL URLWithString:[NSString stringWithFormat:@"http://dev-gw.baofoo.com/apipay/confirm_pay?trade_no=%@&signature=%@&verify_code=%@",_sendDict[@"tradeNo"],_sendDict[@"signature"],messageCode]];
    NSMutableURLRequest*request = [NSMutableURLRequest requestWithURL:url];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *jsonStr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSDictionary*jsondict  =[self dictionaryWithJsonString:jsonStr];
            
            if ([[jsondict objectForKey:@"ret_code"] isEqualToString:@"1"]) {
                
            }
            else
            {
                NSString*str = [jsondict objectForKey:@"error_msg"];
                if (!str) {
                    str = @"创建订单号失败";
                }
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alert show];
            }
        });
    }];

}

-(void)getMessageCode{
    [BF_FangProgressHUD showHUDAddedTo:self animated:YES];
    NSURL*url = [NSURL URLWithString:[NSString stringWithFormat:@"http://dev-gw.baofoo.com/apipay/send_sms?trade_no=%@&signature=%@",_sendDict[@"tradeNo"],_sendDict[@"signature"]]];
    NSMutableURLRequest*request = [NSMutableURLRequest requestWithURL:url];

    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSString *jsonStr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSDictionary*jsondict  =[self dictionaryWithJsonString:jsonStr];
            
            if ([[jsondict objectForKey:@"ret_code"] isEqualToString:@"1"]) {

            }
            else
            {
                //                [BF_FangProgressHUD hideHUDForView:self  animated:YES];
                NSString*str = [dict objectForKey:@"error_code"];
                if (!str) {
                    str = @"创建订单号失败";
                }
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alert show];
            }
        });
    }];
    
}

-(NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}


@end
