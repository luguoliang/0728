//
//  TextView.h
//  fang
//
//  Created by 路国良 on 16/9/21.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextView : UIView
/*
 *
 *dict中需要传入的参数
 *
 * @prarm   tradeNo    商户订单号
 * @prarm   signature  商户签名，用来标示二次支付
 * @prarm   mobile     商户手机号
 */

-(void)showPayViewWithDict:(NSDictionary*)dict;

@end
