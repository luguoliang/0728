//
//  MaxentAddress.h
//  MaxentTrackingSDK
//
//  Created by Macpro on 16/2/1.
//  Copyright © 2016年 maxent. All rights reserved.
//

#import "MaxentBaseObject.h"

@interface MaxentAddress : MaxentBaseObject
@property(nonatomic)NSString * __name;
@property(nonatomic)NSString * __address_1;
@property(nonatomic)NSString * __address_2;
@property(nonatomic)NSString * __city;
@property(nonatomic)NSString * __region;
@property(nonatomic)NSString * __country;
@property(nonatomic)NSString * __zipcode;
@property(nonatomic)NSString * __phone;
@property(nonatomic)NSString * __province;
-(id)CreateAddressWithCountry:(NSString *)country
                     province:(NSString *)province
                         city:(NSString *)city
                       region:(NSString *)region
                     address1:(NSString *)address1
                     address2:(NSString *)address2
                         name:(NSString *)name
                        phone:(NSString *)phone
                      zipcode:(NSString *)zipcode;
@end
