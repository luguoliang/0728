//
//  MaxentBaseObject.h
//  MaxentTrackingSDK
//
//  Created by Macpro on 16/1/31.
//  Copyright © 2016年 maxent. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MaxentBaseObject : NSObject
-(NSString *)YearMonthNSStringWithNSDate:(NSDate *)date;
-(NSString *)genJson;
@end
