//
//  BaofooCertifePay.m
//  fang
//
//  Created by 路国良 on 16/9/20.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "BaofooCertifePay.h"
#import "CountdownButton.h"
#import "BF_FangProgressHUD.h"
#import "TextView.h"
@interface BaofooCertifePay()<UITextFieldDelegate>
{
    
}
@property (nonatomic, strong) NSLayoutConstraint *alertViewCenterYConstraint;

@property (nonatomic, assign) CGFloat alertViewCenterYOffset;

@end

@interface BaofooCertifePay(){
    CountdownButton* _getmessageButton;
    UILabel*_pnumberLabel;
    UITextField*_textField;
}

@end
@implementation BaofooCertifePay

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor  = [UIColor whiteColor];
        _pnumberLabel = [[UILabel alloc] init];
        [self loadView];
        
    }
    return self;
}

-(void)setMobile:(NSString *)mobile{
    _pnumberLabel.text = [NSString stringWithFormat:@"本次交易需要短信确认，校验码已经发送至您的手机%@",mobile];
}
-(void)loadView{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    UILabel*titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 50)];
    [self addSubview:titleLabel];
    titleLabel.text = @"付款确认";
    titleLabel.font = [UIFont systemFontOfSize:20];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    UIView*lineView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(titleLabel.frame), self.frame.size.width, 0.5)];
    lineView.backgroundColor = [UIColor grayColor];
    [self addSubview:lineView];
    lineView.alpha = 0.5;

    _pnumberLabel.frame = CGRectMake(5,  CGRectGetMaxY(lineView.frame), self.frame.size.width - 10, 80);
    _pnumberLabel.numberOfLines = 0;
    titleLabel.font = [UIFont systemFontOfSize:20];
    [self addSubview:_pnumberLabel];
    
    _textField = [[UITextField alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(_pnumberLabel.frame), self.frame.size.width - 10, 50)];
    _textField.delegate = self;
    _textField.placeholder = @"请输入短信验证码";
    _textField.layer.borderColor= [UIColor grayColor].CGColor;
    
    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    CGColorRef color = CGColorCreate(colorSpaceRef, (CGFloat[]){0.1,0,0,0.1});
    [_textField.layer setBorderWidth:0.5];
    [_textField.layer setBorderColor:color];
    _textField.rightViewMode = UITextFieldViewModeAlways;
    _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _textField.clearButtonMode = UITextFieldViewModeNever;
    _textField.keyboardType = UIKeyboardTypeNamePhonePad;
    
    _getmessageButton = [CountdownButton buttonWithType:UIButtonTypeCustom];
    [_getmessageButton setTintColor:[UIColor colorWithRed:0.0/255.0f green:151.0/255.0f blue:209.0/255.0f alpha:1.0f]];
    [_getmessageButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_getmessageButton addTarget:self action:@selector(getCode:)forControlEvents:UIControlEventTouchUpInside];
    
    [_getmessageButton setTitle:@"获取" forState:UIControlStateNormal];
    _getmessageButton.titleLabel.font =[UIFont systemFontOfSize:15.0f];
    
    _getmessageButton.frame = CGRectMake(0, 0, 60, 30);
    
    _textField.rightView = _getmessageButton;
    
    [self addSubview:_textField];
    
    
    UIButton*cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelButton.frame = CGRectMake(0, self.frame.size.height - 50, (self.frame.size.width*0.5)-0.5, 50);
    cancelButton.backgroundColor = [UIColor colorWithRed:239.0/255.0f green:241.0/255.0f blue:243.0/255.0f alpha:1.0];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
    cancelButton.titleLabel.font = [UIFont systemFontOfSize: 20.0];
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    cancelButton.titleLabel.textColor = [UIColor blackColor];
    [cancelButton addTarget:self action:@selector(cancelButton:) forControlEvents:UIControlEventTouchUpInside];
    [cancelButton.layer setBorderWidth:0.5];
    [cancelButton.layer setBorderColor:color];
    [self addSubview:cancelButton];
    
    
    UIButton*okButton = [UIButton buttonWithType:UIButtonTypeCustom];
    okButton.frame = CGRectMake(CGRectGetMaxX(cancelButton.frame), self.frame.size.height - 50, (self.frame.size.width*0.5)+0.5, 50);
    okButton.backgroundColor = [UIColor colorWithRed:239.0/255.0f green:241.0/255.0f blue:243.0/255.0f alpha:1.0];
    [okButton setTitleColor:[UIColor colorWithRed:239.0/255.0f green:98.0/255.0f blue:51.0/255.0f alpha:1.0] forState:UIControlStateNormal];
     okButton.titleLabel.font = [UIFont systemFontOfSize: 20.0];
    [okButton setTitle:@"确定" forState:UIControlStateNormal];
    [okButton addTarget:self action:@selector(okenButton:) forControlEvents:UIControlEventTouchUpInside];
    [okButton setTitleColor:[UIColor colorWithRed:239.0/255.0f green:98.0/255.0f blue:51.0/255.0f alpha:0.2] forState:UIControlStateHighlighted];
    [okButton.layer setBorderWidth:0.5];
    [okButton.layer setBorderColor:color];
    [self addSubview:okButton];
}

-(void)cancelButton:(UIButton*)button{
    [_delegate hide];
}
-(void)okenButton:(UIButton*)button{
    [_delegate okenButtonWithMessageCode:_textField.text];
}
-(void)getCode:(CountdownButton*)btn{
    [btn countDownBegins];
    [_delegate getMessageCode];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (void)keyboardWillShow:(NSNotification*)notification{
//    CGRect keyboardRect = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    CGRect f = self.frame;
    f.origin.y -= 225/2;
    
    self.frame = f;
    [self layoutIfNeeded];
}


- (void)keyboardWillHide:(NSNotification*)notification{
    
    CGRect f = self.frame;
    f.origin.y += 225/2;
    
    self.frame = f;
    [self layoutIfNeeded];
}
-(void)codeStart{
    [_getmessageButton countDownBegins];
     [_textField becomeFirstResponder];
}

@end
