//
//  BaofooCertifePay.h
//  fang
//
//  Created by 路国良 on 16/9/20.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol BF_FangSdkDelegate <NSObject>
/*
 *支付结果回调
 *预加载接口回调
 */
-(void)hide;
-(void)okenButtonWithMessageCode:(NSString*)messageCode;
-(void)getMessageCode;

@end

@interface BaofooCertifePay : UIView

@property(nonatomic,retain)id<BF_FangSdkDelegate>delegate;
@property(nonatomic,copy)NSString*mobile;

-(void)codeStart;
@end
