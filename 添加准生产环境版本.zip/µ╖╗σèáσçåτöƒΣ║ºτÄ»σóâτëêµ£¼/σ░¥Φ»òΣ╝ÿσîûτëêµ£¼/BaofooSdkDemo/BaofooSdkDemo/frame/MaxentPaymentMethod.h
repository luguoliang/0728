//
//  MaxentPaymentMethod.h
//  MaxentTrackingSDK
//
//  Created by Macpro on 16/2/1.
//  Copyright © 2016年 maxent. All rights reserved.
//

#import "MaxentBaseObject.h"
#define PAYMENTTYPE @[@"CASH",@"CREDITCARD",@"THIRDPARTY",@"ECOUPON",@"BITCOIN"];
#define PAYMENTGATEWAY @[@"ALIPAY",@"WEIXINPAY",@"UnionPay",@"PAYPAL"];
#define VERIFICATIONSTATUS @[@"SUCCESS",@"FAIL",@"PENDING"];
//支付方式
typedef enum
{
    MAXENT_PAYMENTTYPE_CASH=0,
    MAXENT_PAYMENTTYPE_CREDITCARD,
    MAXENT_PAYMENTTYPE_THIRDPARTY,
    MAXENT_PAYMENTTYPE_ECOUPON,
    MAXENT_PAYMENTTYPE_BITCOIN
}MAXENT_PAYMENTTYPE;
//支付网关
typedef enum
{
    MAXENT_PAYMENTGATEWAY_ALIPAY=0,
    MAXENT_PAYMENTGATEWAY_WEIXINPAY,
    MAXENT_PAYMENTGATEWAY_UNIONPAY,
    MAXENT_PAYMENTGATEWAY_PAYPAL
}MAXENT_PAYMENTGATEWAY;
//验证结果
typedef enum
{
    MAXENT_VERIFICATIONSTATUS_SUCCESS=0,
    MAXENT_VERIFICATIONSTATUS_FAIL,
    MAXENT_VERIFICATIONSTATUS_PENDING
}MAXENT_VERIFICATIONSTATUS;

@interface MaxentPaymentMethod : MaxentBaseObject
@property(nonatomic)NSString * __payment_type;
@property(nonatomic)NSString * __payment_gateway;
@property(nonatomic)NSString * __card_bin;
@property(nonatomic)NSString * __card_last4;
@property(nonatomic)NSString * __avs_result_code;
@property(nonatomic)NSString * __cvv_result_code;
@property(nonatomic)NSString * __verification_status;
@property(nonatomic)NSString * __routing_number;
@property(nonatomic)NSString * __decline_reason_code;
@property(nonatomic)NSString * __paypal_payer_id;
@property(nonatomic)NSString * __paypal_payer_email;
@property(nonatomic)NSString * __paypal_payer_status;
@property(nonatomic)NSString * __paypal_address_status;
@property(nonatomic)NSString * __paypal_protection_eligibility;
@property(nonatomic)NSString * __paypal_payment_status;
@property(nonatomic)NSString * __stripe_cvc_check;
@property(nonatomic)NSString * __stripe_address_line1_check;
@property(nonatomic)NSString * __stripe_address_line2_check;
@property(nonatomic)NSString * __stripe_address_zip_check;
@property(nonatomic)NSString * __stripe_funding;
@property(nonatomic)NSString * __stripe_brand;

-(id)createPaymentMethodWithPaymentType:(MAXENT_PAYMENTTYPE)paymentType
                         paymentGateway:(MAXENT_PAYMENTGATEWAY)paymentGateway
                               card_bin:(NSString *)card_bin
                             card_last4:(NSString *)card_last4
                            pay_user_id:(NSString *)pay_user_id
                    verification_status:(MAXENT_VERIFICATIONSTATUS)verification_status
                    decline_reason_code:(NSString *)decline_reason_code;
@end
