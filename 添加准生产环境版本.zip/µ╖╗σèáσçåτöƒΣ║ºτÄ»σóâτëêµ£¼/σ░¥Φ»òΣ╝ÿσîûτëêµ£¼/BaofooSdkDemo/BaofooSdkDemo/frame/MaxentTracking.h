
//
//  MaxentTracking.h
//  Mobile Tracker
//
//  Copyright 2014 Maxent Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MaxentItem.h"
#import "MaxentAddress.h"
#import "MaxentPaymentMethod.h"
#define ACTIVATION @"0"
#define REGISTRATION @"1"
#define TRANSACTION @"2"
#define COMPLYSIDE @"3"
#define CUSTOM @"99"
#define ACT2 @"active"
#define ADDITEM @"add_item_to_cart"
#define CREATEACCOUNT @"create_account"
#define CREATECONTENT @"create_content"
#define CREATEORDER @"create_order"
#define CUSTOMIZE @"customize"
#define DELETEITEM @"remove_item_from_cart"
#define INACTIVE @"inactive"
#define LOGIN @"login"
#define LOGOUT @"logout"
#define SENDMESSAGE @"send_message"
#define SUBMITREVIEW @"submit_review"
#define TRANSACTION_NG @"transaction"
#define UPDATEACCOUNT @"update_account"
#define UPDATEORDER @"update_order"
#define MAX_RETRIES 3
#define NGEVENTTYPES @[ACT2,ADDITEM,CREATEACCOUNT,CREATECONTENT,CREATEORDER,CUSTOMIZE,DELETEITEM,INACTIVE,LOGIN,LOGOUT,SENDMESSAGE,SUBMITREVIEW,TRANSACTION_NG,UPDATEACCOUNT,UPDATEORDER];

#define SOCIALSIGNONTYPE @[@"weixin",@"qq",@"weibo",@"alipay",@"facebook",@"others"];
#define TRANSACTIONTYPE @[@"SALE",@"AUTHORIZE",@"CAPTURE",@"VOID",@"REFUND",@"DEPOSIT",@"WITHDRAWAL",@"TRANSFER"];
#define TRANSACTIONSTATUS @[@"SUCCESS",@"FAILURE",@"PENDING"];
#define LOGINSTATUS @[@"SUCCESS",@"FAILURE"];
#define SHIPPINGMETHOD @[@"ELECTRONIC",@"PHYSICAL"];
#define SUBMISSIONSTATUS @[@"SUCCESS",@"FAILURE",@"PENDING"];
#define DEPRECATED __attribute__ ((deprecated))

//第三方登录方法
typedef enum
{
    MAXENT_SOCIALSIGNONTYPE_weixin=0,
    MAXENT_SOCIALSIGNONTYPE_qq,
    MAXENT_SOCIALSIGNONTYPE_weibo,
    MAXENT_SOCIALSIGNONTYPE_alipay,
    MAXENT_SOCIALSIGNONTYPE_facebook,
    MAXENT_SOCIALSIGNONTYPE_others
}MAXENT_SOCIALSIGNONTYPE;
//交易类型
typedef enum
{
    MAXENT_TRANSACTIONTYPE_SALE=0,           //普通售卖
    MAXENT_TRANSACTIONTYPE_AUTHORIZE,      //预授权授权
    MAXENT_TRANSACTIONTYPE_CAPTURE,        //预授权获取
    MAXENT_TRANSACTIONTYPE_VOID,           //撤销预授权
    MAXENT_TRANSACTIONTYPE_REFUND,         //退款
    MAXENT_TRANSACTIONTYPE_DEPOSIT,        //充值
    MAXENT_TRANSACTIONTYPE_WITHDRAWAL,     //取现
    MAXENT_TRANSACTIONTYPE_TRANSFER        //转账
}MAXENT_TRANSACTIONTYPE;
//交易状态
typedef enum
{
    MAXENT_TRANSACTIONSTATUS_SUCCESS=0,
    MAXENT_TRANSACTIONSTATUS_FAILURE,
    MAXENT_TRANSACTIONSTATUS_PENDING
}MAXENT_TRANSACTIONSTATUS;
//登录是否成功
typedef enum
{
    MAXENT_LOGINSTATUS_SUCCESS=0,
    MAXENT_LOGINSTATUS_FAILURE
}MAXENT_LOGINSTATUS;
//交易方式
typedef enum
{
    MAXENT_SHIPPINGMETHOD_ELECTRONIC=0,
    MAXENT_SHIPPINGMETHOD_PHYSICAL
}MAXENT_SHIPPINGMETHOD;
//评论状态
typedef enum
{
    MAXENT_SUBMISSIONSTATUS_SUCCESS=0,
    MAXENT_SUBMISSIONSTATUS_FAILURE,
    MAXENT_SUBMISSIONSTATUS_PENDING
}MAXENT_SUBMISSIONSTATUS;
/*!
 @protocol
 @abstract MaxentTrackingDelegate
 @discussion 
 */


/*!
 @class MaxentTracking
 @abstract this is main class,the user start to tracking by this class。
 */

@interface MaxentTracking : NSObject

@property (nonatomic,copy) NSString *tid;
@property (nonatomic,copy) NSString *key;
@property (nonatomic,copy) NSString *url;
@property (nonatomic,copy) NSString *userId;
@property (nonatomic,copy) NSString *currency;
@property(nonatomic,copy)NSString * sessionID;
@property(nonatomic,copy)NSString * channelName;

+ (MaxentTracking*)sharedInstance;

/*!
 @method   init
 @abstract get MaxentTracking's singleton instance
 @discussion Class method that returns a Singleton object
 @result id
 */

+(id)init:(NSString*)tid;
/**
 *  init with url
 *
 *  @param tid tid
 *  @param url 自定义的tracking server host
 *
 *  @return id
 */
+(id)init:(NSString*)tid url:(NSString *)url;

-(void)reportActivation;

-(void)reportRegistration:(NSString *) userData DEPRECATED;

-(void)reportTransaction:(NSString *)transactionId revenue:(NSString*)revenue;

-(void)reportUserEvent:(NSString *)message DEPRECATED;

-(void)reportComplySideEvent:(NSDictionary *)message;

-(void)reportAct2Event:(NSString *)tact fields:(NSDictionary *)fields DEPRECATED;

-(void)reportActivationWithFields:(NSDictionary *)fields;

-(void)reportAddItemEventWithItem:(MaxentItem *)item fields:(NSDictionary *)fields;

-(void)reportCreateAccountEventWithUserID:(NSString *)userID email:(NSString *)email
                                     name:(NSString *)name
                                    phone:(NSString *)phone
                                 referrer:(NSString *)referrer
                            paymentMethod:(NSArray *)paymentMethod
                                  address:(MaxentAddress *)address
                         socialSignOnType:(MAXENT_SOCIALSIGNONTYPE)socialSignOnType
                                workPhone:(NSString *)workPhone
                                 location:(NSString *)location
                            mailConfirmed:(BOOL)mailConfirmed
                           phoneConfirmed:(BOOL)phoneConfirmed
                                   fields:(NSDictionary *)fields;

-(void)reportCreateContentEventWithContactEmail:(NSString *)contactEmail
                                   contactPhone:(NSString *)contactPhone
                                        subject:(NSString *)subject
                                        content:(NSString *)content
                                         fields:(NSDictionary *)fields;

-(void)reportCreateOrderEventWithOrderID:(NSString *)orderID
                               userEmail:(NSString *)userEmail
                                  amount:(float)amount
                            currencyCode:(NSString *)currencyCode
                          billingAddress:(MaxentAddress *)billingAddress
                          paymentMethods:(NSArray *)paymentMethods
                         shippingAddress:(MaxentAddress *)shippingAddress
                            receiverName:(NSString *)receiverName
                           receiverPhone:(NSString *)receiverPhone
                       expeditedShipping:(BOOL)expeditedShipping
                                   items:(NSArray *)items
                            sellerUserID:(NSString *)sellerUserID
                          shippingMethod:(MAXENT_SHIPPINGMETHOD)shippingMethod
                           promotionName:(NSString *)promotionName
                                  fields:(NSDictionary *)fields;

-(void)reportCustomizeEventWithCustomizeType:(NSString * )customizeType fields:(NSDictionary *)fields;

-(void)reportDeleteItemEventWithItem:(MaxentItem *)item
                              fields:(NSDictionary *)fields;

-(void)reportInactiveEventWithFields:(NSDictionary *)fields;

-(void)reportLoginEventWithUserID:(NSString *)userID LoginStatus:(MAXENT_LOGINSTATUS)loginStatus
                           fields:(NSDictionary *)fields;

-(void)reportLogoutEventWithFields:(NSDictionary *)fields;

-(void)reportSendMessageEventWithReceipientUserID:(NSString *)receipientUserID
                                          subject:(NSString *)subject
                                          content:(NSString *)content
                                           fields:(NSDictionary *)fields;

-(void)reportSubmitReviewEventWithContent:(NSString *)content
                              reviewTitle:(NSString *)reviewTitle
                                   itemID:(NSString *)itemID
                             reviewUserID:(NSString *)reviewUserID
                         submissionStatus:(MAXENT_SUBMISSIONSTATUS)submissionStatus
                                   fields:(NSDictionary *)fields;

-(void)reportTransactionEventWithUserEmail:(NSString *)userEmail
                           transactionType:(MAXENT_TRANSACTIONTYPE)transactionType
                         transactionStatus:(MAXENT_TRANSACTIONSTATUS)transactionStatus
                                    amount:(float)amount
                              currencyCode:(NSString *)currencyCode
                                   orderID:(NSString *)orderID
                             transactionID:(NSString *)transactionID
                            billingAddress:(MaxentAddress *)billingAddress
                             paymentMethod:(MaxentPaymentMethod *)paymentMethod
                           shippingAddress:(MaxentAddress *)shippingAddress
                              sellerUserID:(NSString *)sellerUserID
                   transferRecipientUserID:(NSString *)transferRecipientUserID
                              receiverName:(NSString *)receiverName
                             receiverPhone:(NSString *)receiverPhone
                             promotionName:(NSString *)promotionName
                                     items:(NSArray *)items
                                    fields:(NSDictionary *)fields;

-(void)reportUpdateAccountEventWithUserID:(NSString *)userID ChangedPassword:(BOOL)changedPassword
                                userEmail:(NSString *)userEmail
                                     name:(NSString *)name
                                    phone:(NSString *)phone
                           referrerUserID:(NSString *)referrerUserID
                           paymentMethods:(NSArray *)paymentMethods
                           billingAddress:(MaxentAddress *)billingAddress
                         socialSignOnType:(MAXENT_SOCIALSIGNONTYPE)socialSignOnType
                                workPhone:(NSString *)workPhone
                                 location:(NSString *)location
                            mailConfirmed:(BOOL)mailConfirmed
                           phoneConfirmed:(BOOL)phoneConfirmed
                                   fields:(NSDictionary *)fields;

-(void)reportUpdateOrderEventWithOrderID:(NSString *)orderID
                               userEmail:(NSString *)userEmail
                                  amount:(float)amount
                            currencyCode:(NSString *)currencyCode
                          billingAddress:(MaxentAddress *)billingAddress
                          paymentMethods:(NSArray *)paymentMethods
                         shippingAddress:(MaxentAddress *)shippingAddress
                           receiverPhone:(NSString *)receiverPhone
                            receiverName:(NSString *)receiverName
                       expeditedShipping:(BOOL)expeditedShipping
                                   items:(NSArray *)items
                            sellerUserID:(NSString *)sellerUserID
                          shippingMethod:(MAXENT_SHIPPINGMETHOD)shippingMethod
                           promotionName:(NSString *)promotionName
                                  fields:(NSDictionary *)fields;

@end
