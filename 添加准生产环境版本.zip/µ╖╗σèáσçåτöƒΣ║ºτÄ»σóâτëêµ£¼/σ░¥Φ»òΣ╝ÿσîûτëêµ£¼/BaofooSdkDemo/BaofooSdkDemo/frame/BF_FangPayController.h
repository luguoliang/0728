//
//  BF_FangPayController.h
//  BaoFooPay
//
//  Created by baofoo on 15/3/29.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BF_FangSdkDelegate <NSObject>
/*
 *支付结果回调
 *预加载接口回调
 */
-(void)callBack:(NSString*)statusCode andMessage:(NSString *)message;
-(void)PreloadingcallBack;
@end
@interface BF_FangPayController : UIViewController<UIWebViewDelegate,NSURLConnectionDelegate,NSURLConnectionDataDelegate>

/*
 0:测试环境
 1:准生产环境
 2:正式环境
 */
typedef NS_ENUM(NSInteger,operationalState){
    operational_test = 0,
    operational_associateProduction,
    operational_true
};
@property(nonatomic,assign)operationalState operState;

@property(nonatomic,copy)NSString*tradeNo;
@property(nonatomic,assign,getter =isAuthed)BOOL authed;
@property(nonatomic,retain)id<BF_FangSdkDelegate>delegate;
-(void)PreloadingSDkViewWithSignature:(NSString*)signature;//预加载接口
@end
