//
//  MaxentLib.h
//
//  Created by Maxent Inc.
//  Copyright 2013 Maxent Inc. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netinet/in.h>
#import "ARCMacros.h"


#define STATUS_SUCCESS 200
#define STATUS_MUTE 300
#define STATUS_FAILURE 400
#define STATUS_FIRST   -100

#define SDKVERSION   @"1.0"
#define SleepTracker  @"U2xlZXBUcmVra2VyRmlsZU5hbWUK"
#define APP_VERSION_FILE     @"QXBwVmVyc2lvbgo"
#define APP_VERSION_KEY  @"appVersion"

#define NO_CONNECTIVITY @"noNetwork"
#define NETWORK_WLAN     @"3"
#define NETWORK_WWAN     @"1"

#define NS_WIFI @"1"
#define NS_CELL @"2"



#define SERVICE_LOCATION_ACT  @"http://trk.mxtrk.com/act"
#define SERVICE_LOCATION_EVENT  @"http://trk.mxtrk.com/event"
#define SERVICE_LOCATION_COMPLYSIDE  @"http://trk.mxtrk.com/ngevent"

#define MAXENT_INSTALL @"INSTALL"
#define MAXENT_START @"START"
#define MAXENT_UPGRADE @"UPGRADE"

typedef enum
{
	GPRS=0,
	WWAN=1,
	W3G=2,
	WIFI=3,
	NOT_CONNECTED=4
	
} MxntNetType;

typedef enum {
	MxntNotReachable = 0,
	MxntReachableViaWiFi,
        MxntReachableViaWWAN
} MxntNetworkStatus;

#define kConnChangedNotification @"kNetworkConnChangedNotification"

@interface NSData (Codec)
 
- (NSData *)AES128EncryptWithKey:(NSData *)key;
- (NSData *)AES128DecryptWithKey:(NSData *)key;
- (NSString *)base64EncodedString:(BOOL)urlSafe;
+ (NSString*)base64encode:(NSString*)str;
 
@end
@interface NSString (Codec)
- (NSString *) urlSafeModeConvertedString;
- (NSData*)base64DecodedData;
@end

@interface MaxentConn: NSObject
{
	BOOL localWiFiRef;
	SCNetworkReachabilityRef reachabilityRef;
}


-(void)startCheck;
-(MxntNetType) NetWorkType;
-(void)removeNetWorkObserver;

+ (MaxentConn*) reachabilityWithHostName: (NSString*) hostName;

+ (MaxentConn*) reachabilityWithAddress: (const struct sockaddr_in*) hostAddress;

+ (MaxentConn*) reachabilityForInternetConnection;

+ (MaxentConn*) reachabilityForLocalWiFi;

- (BOOL) startNotifier;
- (void) stopNotifier;

- (NSString *) getNSW;
- (MxntNetworkStatus) currMxntConnStatus: (SCNetworkReachabilityFlags *)reachFlags;
- (BOOL) connRequired;
@end

@interface MaxentLib : NSObject  

+(NSString*)DeviceModel;
+(NSString*)PlatformType;
+(NSString*)PlatformVersion;
+(NSString*)PlatformLanguage;
+(NSString*)getAPN;
+(NSString*)getAppVersion;
+(NSString*)SDKVersion;
+(NSString*)markTrackerFileName;
+(NSString*)markTrackerAppVersionFile;
+(NSString *) platform;
+ (NSString *) platformString;
+ (NSString*)ua;
+(NSString*)idfaID;
+(NSString *)getTact;
+(NSString*)isJailbreak;
+ (NSString *)isnull:(id)string;
+(NSString*)idfvID;
+(NSString*)isEmulator;
+(NSString*)telcoName;
+ (BOOL)overIOS6;
+(BOOL)overIOS7;
+(id)careNil:(id) any;
@end

