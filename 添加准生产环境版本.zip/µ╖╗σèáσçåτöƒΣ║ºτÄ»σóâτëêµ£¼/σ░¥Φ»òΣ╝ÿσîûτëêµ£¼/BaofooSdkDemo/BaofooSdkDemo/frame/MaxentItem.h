//
//  MaxentItem.h
//  MaxentTrackingSDK
//
//  Created by Macpro on 16/2/1.
//  Copyright © 2016年 maxent. All rights reserved.
//

#import "MaxentBaseObject.h"

@interface MaxentItem : MaxentBaseObject
@property(nonatomic)NSString * __item_id;
@property(nonatomic)NSString * __product_title;
@property(nonatomic,assign)float __price;
@property(nonatomic)NSString * __currency_code;
@property(nonatomic)NSInteger __quantity;
@property(nonatomic)NSString * __upc;
@property(nonatomic)NSString * __sku;
@property(nonatomic)NSString * __isbn;
@property(nonatomic)NSString * __brand;
@property(nonatomic)NSString * __manufacturer;
@property(nonatomic)NSString * __category;
@property(nonatomic)NSArray * __tags;
@property(nonatomic)NSString * __color;
@property(nonatomic)NSString * __size;
-(id)createItemWithItemId:(NSString *)itemId
             productTitle:(NSString *)productTitle
                    price:(float)price
             currencyCode:(NSString *)currencyCode
                 quantity:(NSInteger)quantity
                      upc:(NSString *)upc
                      sku:(NSString *)sku
                     isbn:(NSString *)isbn
                    brand:(NSString *)brand
             manufacturer:(NSString *)manufacturer
                 category:(NSString *)category
                     tags:(NSArray *)tags
                    color:(NSString *)color
                     size:(NSString *)size;
@end
