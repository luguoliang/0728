//
//  BF_FangPayController.m
//  BaoFooPay
//
//  Created by baofoo on 15/3/29.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BF_FangPayController.h"
#import "BF_FangProgressHUD.h"
#import "EGISDevice.h"
#import "MaxentTracking.h"
#import "EGISDID.h"
#import "BF_FangPaydes.h"
#import "TextView.h"
@interface BF_FangPayController ()<BF_FangProgressHUDDelegate,UIAlertViewDelegate>
{
    UIWebView*_web;
    NSURLRequest* originRequest;
    BF_FangProgressHUD*hud;
    NSString*judje;
    UIImageView*imageView;
    UIImageView*imageView2;
    NSArray* alertArray;
    NSString*imageStr404h;
    NSString*imageStr404w;
    NSString*imageStrh;
    NSString*imageStrw;
    UIView*ststusBarView;
    BOOL _preStatus;
}
@end

@implementation BF_FangPayController

-(void)PreloadingSDkViewWithSignature:(NSString *)signature{
    if (signature.length) {
        [self getMessageCode:@{@"tradeNo":_tradeNo,@"signature":signature}];
        return;
    }
    _preStatus = YES;
    [self loada];
}


-(void)showPayView:(NSDictionary*)dict{
    TextView*test = [TextView alloc];
    [test showPayViewWithDict:dict];
}

#pragma mark  - getMessaheCode
-(void)getMessageCode:(NSDictionary*)dict{
    NSString*urlStr = @"";
    switch (self.operState) {
        case 0:
        {
            urlStr = [NSString stringWithFormat:@"http://dev-gw.baofoo.com/apipay/send_sms?"];
        }
            break;
        case 1:
        {
            urlStr = [NSString stringWithFormat:@"http://qas-gw.baofoo.com/apipay/send_sms?"];
        }
            break;
        case 2:
        {
            urlStr = [NSString stringWithFormat:@"http://gw.baofoo.com/apipay/send_sms?"];
        }
            break;
            
        default:
        {
            [self returnOperatingResult:@"-1,8888:请传入正确的操作环境"];
            return;
        }
            break;
    }
    
    NSURL*url = [NSURL URLWithString:[NSString stringWithFormat:@"%@trade_no=%@&signature=%@",urlStr,dict[@"tradeNo"],dict[@"signature"]]];
    NSMutableURLRequest*request = [NSMutableURLRequest requestWithURL:url];
    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *jsonStr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSDictionary*jsondict  =[self dictionaryWithJsonString:jsonStr];
            
            if ([[jsondict objectForKey:@"ret_code"] isEqualToString:@"1"]) {
            
                [self showPayView:@{@"tradeNo":_tradeNo,@"signature":dict[@"signature"],@"mobile":jsondict[@"mobile"]}];
                
            }
            else
            {
                NSString*str = [dict objectForKey:@"error_code"];
                if (!str) {
                    str = @"创建订单号失败";
                }
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alert show];
                
                
                
                
            }
        });
    }];
    
}

-(NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}


-(void)loada{
    judje = @"0";
    self.view.backgroundColor = [UIColor whiteColor];
    ststusBarView = [[UIView alloc] init];
    [self.view addSubview:ststusBarView];
    ststusBarView.backgroundColor = [UIColor whiteColor];
#pragma mark
    ststusBarView.translatesAutoresizingMaskIntoConstraints = NO;
    NSArray*stsConstraintsW  = [NSLayoutConstraint
                                constraintsWithVisualFormat:@"V:|-0-[view(20)]"
                                options:0
                                metrics:nil views:@{@"view":ststusBarView}
                                ];
    [self.view addConstraints:stsConstraintsW];
    
    NSArray*stsConstraintsH = [NSLayoutConstraint
                               constraintsWithVisualFormat:@"H:|-0-[view]-0-|"
                               options:0
                               metrics:nil views:@{@"view":ststusBarView}
                               ];
    [self.view addConstraints:stsConstraintsH];
#pragma mark
    _web = [[UIWebView alloc] init];
    [self.view addSubview:_web];
    _web.scrollView.alwaysBounceVertical = NO;
    _web.scrollView.alwaysBounceHorizontal = NO;
    _web.scrollView.showsVerticalScrollIndicator = NO;
    _web.scrollView.showsHorizontalScrollIndicator = NO;
    _web.delegate = self;
    _web.translatesAutoresizingMaskIntoConstraints = NO;
    _web.scrollView.bounces = NO;
    _web.hidden = YES;
    NSArray*webArrayH = [NSLayoutConstraint
                         constraintsWithVisualFormat:@"V:[view]-0-[web]-0-|"
                         options:0
                         metrics:nil views:@{@"web":_web,@"view":ststusBarView}
                         ];
    [self.view addConstraints:webArrayH];
    
    
    NSArray*webArrayW = [NSLayoutConstraint
                         constraintsWithVisualFormat:@"H:|-0-[web]-0-|"
                         options:0
                         metrics:nil views:@{@"web":_web}
                         ];
    [self.view addConstraints:webArrayW];
    hud = [BF_FangProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.color = [UIColor grayColor];
    [hud hide:YES afterDelay:0];
    hud.yOffset = 0;
    hud.delegate = self;
    hud.hidden = NO;
    [self loadHtml:nil];
    [self loadurlString];
    
    
#pragma mark - 监听屏幕旋转的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange:) name:UIDeviceOrientationDidChangeNotification object:nil];
}

-(void)loadurlString{
    NSString*urlStr = @"";
    switch (self.operState) {
        case 0:
        {
//            urlStr = [NSString stringWithFormat:@"https://dev-gw.baofoo.com/apipay/order_request"];
//              urlStr = [NSString stringWithFormat:@"https://tgw.baofoo.com/apipay/order_request"];
            urlStr = [NSString stringWithFormat:@"http://10.1.60.26:8888/apipay/order_request"];
        }
            break;
        case 1:
        {
            urlStr = [NSString stringWithFormat:@"http://qas-gw.baofoo.com/apipay/order_request"];
        }
            break;
        case 2:
        {
            urlStr = [NSString stringWithFormat:@"https://gw.baofoo.com/apipay/order_request"];
        }
            break;
            
        default:
        {
            [self returnOperatingResult:@"-1,8888:请传入正确的操作环境"];
            return;
        }
            break;
    }
    [self loadHtml:urlStr];
}

- (void)viewDidLoad {
    
}
-(void)loadHtml:(NSString*)Strss
{
    
    NSURL*url = [NSURL URLWithString:Strss];
    
    NSString*urlStr = [NSString stringWithFormat:@"<html><head><meta charset='utf-8'></head><body onload='payform.submit()'><form name='payform' action=\"%@\" method='post'><input type='hidden' name='tradeNo' value='%@'/><input type='hidden' name='version' value='1.0.0' /></form><body></html>",url,_tradeNo];
    
    [_web loadHTMLString:urlStr baseURL:nil];
}

#pragma mark -  UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString*scheme = [[request URL] scheme];
    if ([scheme isEqualToString:@"https"]) {
        //如果是https:的话，那么就用NSURLConnection来重发请求。从而在请求的过程当中吧要请求的URL做信任处理。
        if (!self.isAuthed) {
            originRequest = request;
            NSURLConnection* conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
            [conn start];
            [_web stopLoading];
            return NO;
        }
    }
    NSString*urlString = [[request URL] absoluteString];
    NSLog(@"%@",urlString);
    if ([urlString length]<=17) {
        return YES;
    }
#pragma mark 去掉http://
    NSString *urlScheme = [urlString substringFromIndex:7];

    if ([[urlScheme lastPathComponent] isEqualToString:@"/"]) {
        urlScheme = [urlScheme substringToIndex:[urlScheme length] - 1];
    }
    if ([urlScheme rangeOfString:@"baofoosdk/saveData"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        if ([splitFuncInfo lastObject]) {
            [self SaveWebDataToLocal:[[splitFuncInfo lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
        }
        else
        {
            [self SaveWebDataToLocal:@""];
        }
        
    }
    else if ([urlScheme rangeOfString:@"baofoosdk/readData"].location != NSNotFound)
    {
        judje = @"1";
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString*str = [self ReadData];
        
        if (str.length == 0) {
            str = @"";
        }
        NSString*calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",[splitFuncInfo objectAtIndex:2],str];
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }
    else if ([urlScheme rangeOfString:@"baofoosdk/payResult"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString *params = [splitFuncInfo lastObject];
        params = [params stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [self returnOperatingResult:params];
    }
    else if ([urlScheme rangeOfString:@"baofoosdk/alert"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString *params = [[splitFuncInfo lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        //params = [params stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        //[self returnOperatingResult:params];
        
        NSString* str =  params;
        
        [self jsCallAlert:str];
    }
    
    else if ([urlScheme rangeOfString:@"baofoosdk/confirm"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString *params = [[splitFuncInfo lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        alertArray = [params componentsSeparatedByString:@","];
        [self jsCallconfirm:alertArray];
    }
    else if ([urlScheme rangeOfString:@"baofoosdk/statusbarcolor"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString *params = [[splitFuncInfo lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [[NSUserDefaults standardUserDefaults] setObject:params forKey:@"bf_statusbarcolor"];
        }
    else if ([urlScheme rangeOfString:@"baofoosdk/notifySessionId"].location != NSNotFound)
    {
        NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
        NSString *params = [[splitFuncInfo lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSArray* notifySessionId = [params componentsSeparatedByString:@","];
//        NSData*data = [[notifySessionId lastObject] dataUsingEncoding:NSUTF8StringEncoding];
//        NSData*sre =   [BF_FangPaydes DESDecrypt:data WithKey:@"card.encrypt.baofoo.com"];
        NSString*notifction = [self DESDecrypt:[notifySessionId lastObject] WithKey:@"card.encrypt.baofoo.com"];
        [self sdkinitWithSession:notifction];
    }
    NSArray *splitFuncInfo = [urlScheme componentsSeparatedByString:@"/"];
    if ([[splitFuncInfo lastObject] isEqualToString:@"order_request"]) {
        judje = @"1";
    }
    return YES;
    
}
-(void)sdkinitWithSession:(NSString*)session{
    
    /*
     *EGISSecurityContextAppId :登录www.payegis.com 获取app ID
     *EGISSecurityContextAppKey:登录www.payegis.com 获取app key
     *EGISSecurityContextSession:从app服务器获取的session
     */
    //    session = @"session_from_app_server";
    NSMutableArray *marray = [NSMutableArray arrayWithArray:[session componentsSeparatedByString:@"_"]];
    NSString*strl = [marray lastObject];
    [marray removeLastObject];
    NSString*strf = [marray lastObject];
    
    NSString*sestr = [NSString stringWithFormat:@"%@%@",strf,strl];
    
    NSString*seesionID = [NSString stringWithFormat:@"%@%@",sestr,@"sdk"];
    
    NSDictionary *context=@{EGISSecurityContextAppId:@"2224194",
                            EGISSecurityContextAppKey:@"4e5624ef90e143fc92762e82d7317bd1",
                            EGISSecurityContextSession:seesionID
                            };
    /*
     Maxent
     */
    //
    MaxentTracking* tracker=[MaxentTracking init:@"190b3a7d58743dcea90bc8f161e86a33"];
    [tracker setCurrency:@"CNY"];
    [tracker setUserId:@"1"];
    [tracker setSessionID:sestr];
    [[MaxentTracking sharedInstance] reportSubmitReviewEventWithContent:@"content" reviewTitle:@"宝付sdk" itemID:@"baofoosdk" reviewUserID:@"reviewuserid" submissionStatus:MAXENT_SUBMISSIONSTATUS_SUCCESS fields:@{@"asdas":@"dasdasd"}];
    [tracker reportActivation];
    
    //
    [EGISDID init:context completionBlock:^(NSError *error){
        if(error){
            NSLog(@"error description is %@", [error localizedDescription]);
            if (!([[error localizedDescription] isEqualToString:@"SDK已初始化"])) {
             [self callBacktoRiskControlWith:@{@"key":session,@"state":@"0"}];
            }
        }else{
            
            NSLog(@"error description is %@", [error localizedDescription]);
            
            [self callBacktoRiskControlWith:@{@"key":session,@"state":@"1"}];
            
            
        }
    }];
}

-(void)sdkInitWithXingYiWithSession:(NSString*)session{
    
    NSMutableArray *marray = [NSMutableArray arrayWithArray:[session componentsSeparatedByString:@"_"]];
    NSString*strl = [marray lastObject];
    [marray removeLastObject];
    NSString*strf = [marray lastObject];
    NSString*sestr = [NSString stringWithFormat:@"%@%@",strf,strl];
    MaxentTracking* tracker=[MaxentTracking init:@"190b3a7d58743dcea90bc8f161e86a33"];
    [tracker setCurrency:@"CNY"];
    [tracker setUserId:@"1"];
    [tracker setSessionID:sestr];
    [[MaxentTracking sharedInstance] reportSubmitReviewEventWithContent:@"content" reviewTitle:@"宝付sdk" itemID:@"baofoosdk" reviewUserID:@"reviewuserid" submissionStatus:MAXENT_SUBMISSIONSTATUS_SUCCESS fields:@{@"asdas":@"dasdasd"}];
    [tracker reportActivation];
}

-(void)callBacktoRiskControlWith:(NSDictionary*)dict{
    [BF_FangProgressHUD hideHUDForView:self.view animated:YES];
    NSURL*url = nil;
    switch (self.operState) {
        case 0:
        {
            url = [NSURL URLWithString:@"http://tfk.baofoo.com/baofoo-rm-front/collectSdkDevice.do"];
        }
            break;
        case 1:
        {
            url = [NSURL URLWithString:@"https://fk.baofoo.com/collectSdkDevice.do"];
        }
            break;
        case 2:
        {
            url = [NSURL URLWithString:@"https://fk.baofoo.com/collectSdkDevice.do"];
        }
            break;
            
        default:
            break;
    }
    NSMutableURLRequest*request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    NSString*sdk  = [NSString stringWithFormat:@"%@%@",dict[@"key"],@"sdk"];
    NSString *para = [NSString stringWithFormat:@"%@=%@&%@=%@",
                      @"key",sdk,
                      @"state",dict[@"state"]
                      ];
    [request setHTTPBody:[para dataUsingEncoding:NSUTF8StringEncoding]];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSDictionary *dictr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSLog(@"dictr = %@",dictr);
        });
    }];
    NSLog(@"dict = %@",dict);
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if ([judje isEqualToString:@"1"]) {
        [self performSelector:@selector(webdelayMehod) withObject:nil afterDelay:0];
    }
    NSString *jsToGetHTMLSource = @"document.getElementsByTagName('h1')[0].innerHTML";
    NSString *HTMLSource = [webView stringByEvaluatingJavaScriptFromString:jsToGetHTMLSource];
    if ([HTMLSource rangeOfString:@"HTTP Status 404"].location != NSNotFound) {
        [self performSelector:@selector(stasMehod) withObject:nil afterDelay:3.0];
    }
}

-(void)stasMehod
{
//    if (_preStatus) {
//        [_delegate PreloadingcallBack];
//        _preStatus = NO;
//    }
//    [hud hide:YES];
//    imageView.hidden = YES;
//    imageView2.hidden = NO;
//    hud.hidden = YES;
//    _web.hidden = YES;
//    judje = @"1";
//    [self performSelector:@selector(delayMehod) withObject:nil afterDelay:3];


    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@"" message:@"" delegate:nil cancelButtonTitle:@"aa" otherButtonTitles:@"", nil];
    [alert show];
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSString*str  = [NSString stringWithFormat:@"%ld",(long)error.code];
    if ([str isEqualToString:@"-1004"]) {
        [self returnOperatingResult:@"-1,9999:亲，网络连接有问题哦，请检查网路后再试"];
    }
}

#pragma mark － NSURLConnectionDelegate <NSObject>
- (BOOL)connectionShouldUseCredentialStorage:(NSURLConnection *)connection
{
    return YES;
}
- (void)connection:(NSURLConnection *)connection willSendRequestForAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    if ([challenge previousFailureCount]== 0) {
        _authed = YES;
        //NSURLCredential 这个类是表示身份验证凭据不可变对象。凭证的实际类型声明的类的构造函数来确定。
        NSURLCredential* cre = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
        [challenge.sender useCredential:cre forAuthenticationChallenge:challenge];
    }
    else
    {
        [challenge.sender cancelAuthenticationChallenge:challenge];
    }
    
}
// Deprecated authentication delegates.
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace
{
    return [protectionSpace.authenticationMethod
            isEqualToString:NSURLAuthenticationMethodServerTrust];
    return YES;
}
- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}
#pragma mark － NSURLConnectionDataDelegate <NSURLConnectionDelegate>
- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    return request;
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.authed = YES;
    [_web loadRequest:originRequest];
    [connection cancel];
}
#pragma mark js调用本地方法
-(void)SaveWebDataToLocal:(NSString*)data
{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setValue:data forKey:@"baofooSdk"];
}

-(void)returnOperatingResult:(NSString*)result
{
    NSArray *resultArr = [result componentsSeparatedByString:@","];
    [_delegate callBack:[resultArr firstObject] andMessage:[resultArr lastObject]];
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString*yescalljs = [NSString stringWithFormat:@"%@()",[alertArray objectAtIndex:1]];
    NSString*nocalljs = [NSString stringWithFormat:@"%@()",[alertArray objectAtIndex:2]];
    switch (buttonIndex) {
        case 0:
            [_web stringByEvaluatingJavaScriptFromString:nocalljs];
            break;
        case 1:
            [_web stringByEvaluatingJavaScriptFromString:yescalljs];
            break;
            
        default:
            break;
    }
}
#pragma mark - js调用本地alert confirm
-(void)jsCallAlert:(NSString*)aletr
{
    NSString*str = aletr;
    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@""
                                                   message:str
                                                  delegate:nil
                                         cancelButtonTitle:@"取消"
                                         otherButtonTitles:nil, nil];
    
    [alert show];
}




#pragma mark - js调用本地alert confirmsxaa
-(void)jsCallconfirm:(NSArray*)aletr
{
    
    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@""
                                                   message:[aletr objectAtIndex:0]
                                                  delegate:self
                                         cancelButtonTitle:@"取消"
                                         otherButtonTitles:@"确定", nil];
    [alert show];
}
#pragma mark -
- (void)orientChange:(NSNotification *)noti
{
    
}
#pragma mark
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
}


#pragma mark 开始画面延时
-(void)webdelayMehod
{
    imageView.hidden = YES;
    hud.hidden = YES;
    _web.hidden = NO;//web显示
    //#0099ff
    

    NSString*params = [[NSUserDefaults standardUserDefaults] objectForKey:@"bf_statusbarcolor"];
//    if ([params isEqualToString:@""]) {
//        ststusBarView.backgroundColor = [UIColor clearColor];
//    }
//    else {
//        ststusBarView.backgroundColor = [self BF_FangColorWithHexString:params alpha:1.0];
//    }
//    if (_preStatus) {
//        [_delegate PreloadingcallBack];
//        _preStatus = NO;
//    }
//    if ([params isEqualToString:@""]) {
//        ststusBarView.backgroundColor = [UIColor clearColor];
//    }
//    else {
//        ststusBarView.backgroundColor = [self BF_FangColorWithHexString:params alpha:1.0];
//    }
//
   
    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@"" message:@"" delegate:nil cancelButtonTitle:@"aa" otherButtonTitles:@"", nil];
    [alert show];

}
#pragma mark 404延时调用
-(void)delayMehod
{
    
    [self returnOperatingResult:@"-1,9999:亲，网络连接有问题哦，请检查网路后再试"];
}
#pragma mark - js读取本地方法
-(NSString*)ReadData
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults objectForKey:@"baofooSdk"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(UIColor*)BF_FangColorWithHexString:(NSString *)color alpha:(CGFloat)alpha
{
    //删除字符串中的空格
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6)
    {
        return [UIColor clearColor];
    }
    // strip 0X if it appears
    //如果是0x开头的，那么截取字符串，字符串从索引为2的位置开始，一直到末尾
    if ([cString hasPrefix:@"0X"])
    {
        cString = [cString substringFromIndex:2];
    }
    //如果是#开头的，那么截取字符串，字符串从索引为1的位置开始，一直到末尾
    if ([cString hasPrefix:@"#"])
    {
        cString = [cString substringFromIndex:1];
    }
    if ([cString length] != 6)
    {
        return [UIColor clearColor];
    }
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float)r / 255.0f) green:((float)g / 255.0f) blue:((float)b / 255.0f) alpha:alpha];
}

//des加密
-(NSString *)DESDecrypt:(NSString *)str WithKey:(NSString *)key
{
    key = @"card.encrypt.baofoo.com";
    NSData* data = [self dataFromHexString:str];
    char keyPtr[kCCKeySizeAES256+1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesDecrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyPtr, kCCBlockSizeDES,
                                          nil,
                                          [data bytes], dataLength,
                                          buffer, bufferSize,
                                          &numBytesDecrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *dattaa = [NSData dataWithBytesNoCopy:buffer length:numBytesDecrypted];
        NSString*sss = [[NSString alloc] initWithData:dattaa encoding:NSUTF8StringEncoding];
        return sss;
    }
    free(buffer);
    return nil;
}

-(NSData * ) dataFromHexString : (NSString *) s_t {
    s_t = [s_t stringByReplacingOccurrencesOfString:@" "  withString: @""];
    if ([s_t length]%2 !=0)
    {
        return nil;
    }
    Byte * retBytes = malloc(sizeof(char) * [s_t length]);
    Byte * ori = retBytes;
    for ( int i = 0 ; i < [s_t length]; )
    {
        char highBit = [s_t characterAtIndex:i ++];
        char lowBit = [s_t characterAtIndex:i ++];
        Byte a = [self numFromChar:highBit];
        Byte b = [self numFromChar:lowBit];
        *(retBytes ++)= (a<<4) | b;
    }
    
    NSData * data = [NSData dataWithBytes:ori length:[s_t length]/2];
    
    return data;
}

- (Byte ) numFromChar : (char ) c
{
    if ( c >='0' && c <= '9')
    {
        return c - '0';
    }else if (c >='A' && c <='Z') {
        return c - 'A' + 10;
    }else if (c >='a' && c <= 'z') {
        return c - 'a' + 10;
    }
    return -1;
}

@end
